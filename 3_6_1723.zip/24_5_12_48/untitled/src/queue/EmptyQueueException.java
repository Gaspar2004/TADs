package queue;

public class EmptyQueueException extends Exception {
}

package stack;

public class EmptyStackException extends Exception {
}

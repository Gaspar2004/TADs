package BST;

import linked_list.linked_list_interface;

public class BST <K extends Comparable<K>, T> implements BST_interfaz<K,T>{
    private Nodo_arbol<K,T> root;



    @Override
    //por que nos falla cuando creamos el nodo?
    public void add(K key, T value) {
        Nodo_arbol<K,T> elemento_a_agregar = new Nodo_arbol<>(key, value);
        if (root == null) {
            root = elemento_a_agregar;
        } else {
            root.add(key, value);
        }

    }

    @Override
    public T find(K key) {
        return null; //find(key, root);
    }

    @Override
    public boolean contains(K key) {
        return false;
    }

    @Override
    public void remove(K key) {

    }

    @Override
    public T findMin() {
        return null;
    }

    @Override
    public T findMax() {
        return null;
    }

    @Override
    public linked_list_interface<K> inOrder() {
        return null;
    }


}
